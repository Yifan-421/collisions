// // Shape Class for simulation
// class Shape {
//     constructor(x, y, dx, dy, size, id, type) {
//         this.id = id;
//         this.x = x;
//         this.y = y;
//         this.dx = dx;
//         this.dy = dy;
//         this.size = size;
//         this.collisions = 0;
//         this.type = type; // 'circle' or 'rectangle'
//     }

//     move(bounds) {
//         this.x += this.dx;
//         this.y += this.dy;

//         // Bounce on boundary collision
//         if (this.x <= 0 || this.x >= bounds.width) this.dx *= -1;
//         if (this.y <= 0 || this.y >= bounds.height) this.dy *= -1;
//     }

//     checkCollision(other) {
//         if (this.type === 'circle' && other.type === 'circle') {
//             // Circle-to-circle collision
//             const dist = Math.sqrt(
//                 (this.x - other.x) ** 2 + (this.y - other.y) ** 2
//             );
//             return dist < this.size + other.size;
//         } else {
//             // Basic collision approximation for rectangle or mixed types
//             return Math.abs(this.x - other.x) < this.size + other.size &&
//                    Math.abs(this.y - other.y) < this.size + other.size;
//         }
//     }
// }

// // Simulation function
// function simulate(bounds, steps = 100, numShapes = 20) {
//     const shapes = [];

//     // Initialize shapes
//     for (let i = 0; i < numShapes; i++) {
//         const size = Math.random() * 20 + 10;
//         const x = Math.random() * bounds.width;
//         const y = Math.random() * bounds.height;
//         const dx = (Math.random() - 0.5) * 4;
//         const dy = (Math.random() - 0.5) * 4;
//         const type = Math.random() > 0.5? 'circle' : 'rectangle';
//         shapes.push(new Shape(x, y, dx, dy, size, i, type));
//     }

//     // Run simulation
//     for (let step = 0; step < steps; step++) {
//         console.log(`Step ${step + 1}`);
//         shapes.forEach((shape) => {
//             shape.move(bounds);

//             // Check collisions
//             shapes.forEach((other) => {
//                 if (shape!== other && shape.checkCollision(other)) {
//                     shape.collisions++;
//                     console.log(`Shape ${shape.id} (${shape.type}) collided with Shape ${other.id} (${other.type})`);
//                 }
//             });
//         });

//         // Remove shapes with >= 3 collisions
//         for (let i = shapes.length - 1; i >= 0; i--) {
//             if (shapes[i].collisions >= 3) {
//                 console.log(`Shape ${shapes[i].id} removed after ${shapes[i].collisions} collisions`);
//                 shapes.splice(i, 1);
//             }
//         }

//         // Print remaining shapes
//         console.log(`Remaining shapes: ${shapes.length}`);
//         console.log('---');
//     }

//     console.log('Simulation complete.');
// }

// // Run the simulation
// simulate({ width: 800, height: 600 });

document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('simulationCanvas');
    const ctx = canvas.getContext('2d');
    canvas.width = 800;
    canvas.height = 600;

    const stats = {
        fps: document.getElementById('fps'),
        remainingShapes: document.getElementById('remainingShapes'),
    };

    class Shape {
        constructor(x, y, dx, dy, size, color, type, cartoonStyle) {
            this.x = x;
            this.y = y;
            this.dx = dx;
            this.dy = dy;
            this.size = size;
            this.color = color;
            this.type = type; // 'circle' or 'rectangle'
            this.cartoonStyle = cartoonStyle; // 新增属性：卡通样式
            this.collisions = 0;
        }

        draw() {
            ctx.fillStyle = this.color;
            if (this.type === 'circle') {
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.closePath();
                ctx.fill();
                if (this.cartoonStyle) {
                    // 绘制卡通眼睛
                    ctx.fillStyle = 'black';
                    ctx.beginPath();
                    ctx.arc(this.x - this.size / 3, this.y - this.size / 3, this.size / 6, 0, Math.PI * 2);
                    ctx.closePath();
                    ctx.fill();
                    ctx.beginPath();
                    ctx.arc(this.x + this.size / 3, this.y - this.size / 3, this.size / 6, 0, Math.PI * 2);
                    ctx.closePath();
                    ctx.fill();
                }
            } else if (this.type === 'rectangle') {
                ctx.fillRect(this.x, this.y, this.size * 2, this.size);
                if (this.cartoonStyle) {
                    // 绘制卡通嘴巴
                    ctx.beginPath();
                    ctx.arc(this.x + this.size, this.y + this.size / 2, this.size / 4, 0, Math.PI, true);
                    ctx.closePath();
                    ctx.fill();
                }
            }
        }

        move() {
            this.x += this.dx;
            this.y += this.dy;

            if (this.x <= 0 || this.x >= canvas.width - this.size * (this.type === 'rectangle'? 2 : 1)) this.dx *= -1;
            if (this.y <= 0 || this.y >= canvas.height - this.size) this.dy *= -1;
        }

        checkCollision(other) {
            if (this.type === 'circle' && other.type === 'circle') {
                const dist = Math.hypot(this.x - other.x, this.y - other.y);
                return dist < this.size + other.size;
            } else if (this.type === 'rectangle' && other.type === 'rectangle') {
                return (
                    this.x < other.x + other.size * 2 &&
                    this.x + this.size * 2 > other.x &&
                    this.y < other.y + other.size &&
                    this.y + this.size > other.y
                );
            } else {
                const circle = this.type === 'circle'? this : other;
                const rect = this.type === 'rectangle'? this : other;
                const distX = Math.abs(circle.x - rect.x - rect.size);
                const distY = Math.abs(circle.y - rect.y - rect.size / 2);
                if (distX > rect.size + circle.size || distY > rect.size + circle.size) return false;
                if (distX <= rect.size || distY <= rect.size) return true;
                return (
                    Math.pow(distX - rect.size, 2) + Math.pow(distY - rect.size, 2) <=
                    Math.pow(circle.size, 2)
                );
            }
        }
    }

    const shapes = [];
    for (let i = 0; i < 50; i++) {
        const size = Math.random() * 20 + 10;
        const x = Math.random() * (canvas.width - size * 2);
        const y = Math.random() * (canvas.height - size * 2);
        const dx = (Math.random() - 0.5) * 4;
        const dy = (Math.random() - 0.5) * 4;
        const color = '#' + Math.floor(Math.random() * 16777215).toString(16);
        const type = Math.random() > 0.5? 'circle' : 'rectangle';
        const cartoonStyle = Math.random() > 0.5; // 随机决定是否使用卡通样式
        shapes.push(new Shape(x, y, dx, dy, size, color, type, cartoonStyle));
    }

    let lastFrameTime = performance.now();
    let frameCount = 0;

    function calculateFPS() {
        const currentTime = performance.now();
        frameCount++;
        const elapsed = currentTime - lastFrameTime;

        if (elapsed >= 1000) {
            stats.fps.textContent = `FPS: ${frameCount}`;
            frameCount = 0;
            lastFrameTime = currentTime;
        }
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        shapes.forEach((shape, index) => {
            shape.move();
            shape.draw();

            shapes.forEach((other, otherIndex) => {
                if (index!== otherIndex && shape.checkCollision(other)) {
                    shape.collisions++;
                    shape.color = '#' + Math.floor(Math.random() * 16777215).toString(16);

                    if (shape.collisions >= 3) {
                        shapes.splice(index, 1);
                    }
                }
            });
        });

        stats.remainingShapes.textContent = `Remaining Shapes: ${shapes.length}`;
        calculateFPS();

        requestAnimationFrame(animate);
    }

    animate();
});