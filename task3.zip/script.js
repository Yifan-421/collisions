document.addEventListener('DOMContentLoaded', () => {
    const teamsData = [
        { "name": "Red Dragons FC", "totalPoints": 82 },
        { "name": "Atlas United", "totalPoints": 77 },
        { "name": "Quantum Warriors", "totalPoints": 74 },
        { "name": "Storm City", "totalPoints": 66 },
        { "name": "Royal Phoenix", "totalPoints": 63 },
        { "name": "Black Bears Athletic", "totalPoints": 59 },
        { "name": "Silver Knights", "totalPoints": 57 },
        { "name": "Thunder Valley FC", "totalPoints": 54 },
        { "name": "Golden Eagles United", "totalPoints": 52 },
        { "name": "Emerald Titans", "totalPoints": 48 },
        { "name": "Arctic Wolves", "totalPoints": 46 },
        { "name": "Crystal Lake FC", "totalPoints": 43 },
        { "name": "Metro Stars", "totalPoints": 42 },
        { "name": "Iron Giants", "totalPoints": 39 },
        { "name": "Blue Hurricanes", "totalPoints": 37 },
        { "name": "Mountain Lions", "totalPoints": 34 },
        { "name": "Sunset Raiders", "totalPoints": 31 },
        { "name": "Victory Athletic", "totalPoints": 29 },
        { "name": "Northern Lights FC", "totalPoints": 26 },
        { "name": "Crimson Legends", "totalPoints": 25 }
    ];

    const tableBody = document.getElementById('leaderboard-table-body');

    teamsData.forEach((team, index) => {
        const row = document.createElement('tr');
        
        const rankCell = document.createElement('td');
        rankCell.textContent = index + 1;
        row.appendChild(rankCell);

        const nameCell = document.createElement('td');
        nameCell.textContent = team.name;
        row.appendChild(nameCell);

        const pointsCell = document.createElement('td');
        pointsCell.textContent = team.totalPoints;
        row.appendChild(pointsCell);

        tableBody.appendChild(row);
    });
});